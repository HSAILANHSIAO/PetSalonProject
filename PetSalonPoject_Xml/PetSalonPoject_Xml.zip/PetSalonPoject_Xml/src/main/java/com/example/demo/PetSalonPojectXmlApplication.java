package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetSalonPojectXmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetSalonPojectXmlApplication.class, args);
	}

}
